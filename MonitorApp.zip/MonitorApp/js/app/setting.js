
mui.init();
(function($, doc) {
	
}(mui, document));
