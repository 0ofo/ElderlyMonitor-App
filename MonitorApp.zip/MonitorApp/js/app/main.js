mui.init();
(function($, doc) {
	mui('body').on('tap','a',function(){document.location.href=this.href;});
	$.plusReady(function() {
		var first = null;
		mui.back = function() { //首次按键，提示‘再按一次退出应用’  
			if (!first) {
				first = new Date().getTime();
				mui.toast('再按一次退出应用');
				setTimeout(function() {
					first = null;
				}, 2000);
			} else {
				if (new Date().getTime() - first < 2000) {
					plus.runtime.quit();
				}
			}
		};
	});
}(mui, document));
