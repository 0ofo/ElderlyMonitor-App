var server = "http://18r.site:18/";
(function($, doc) {
	$.init();
	$.plusReady(function() {
		var first = null;
		mui.back = function() { //首次按键，提示‘再按一次退出应用’  
			if (!first) {
				first = new Date().getTime();
				mui.toast('再按一次退出应用');
				setTimeout(function() {
					first = null;
				}, 2000);
			} else {
				if (new Date().getTime() - first < 2000) {
					plus.runtime.quit();
				}
			}
		};
		plus.navigator.setStatusBarStyle('dark');
		function autoLogin() {
			var autoLogin = document.getElementById("autoLogin").classList.contains("mui-active");
			var user = localStorage.getItem("user");
			if (!autoLogin || user == null || user == "") {
				return;
			}
			var mail = localStorage.getItem("mail");
			var pw = localStorage.getItem("pw");
			//if(mail==null||pw=null){return;}
			$.post(server + "user/login", {
				mail: mail,
				password: pw
			}, function(data) {
				if (data.code == 0) {
					return;
				}
				mui.toast('登陆成功，自动跳转到主页面', {
					duration: '2000',
					type: 'div'
				})
				localStorage.setItem("user", JSON.stringify(data.user));
				window.location.href = "main.html";
			});
		}
		autoLogin();
	});
}(mui, document));


$(document).ready(function() {
	var mail = $("#mail");
	var pw = $("#password");
	var login = $("#login");
	login.click(function() {
		if (mail.val() == "" || pw.val() == "") {
			mui.toast('请填写登陆信息', {
				duration: '2000',
				type: 'div'
			});
			return;
		}
		$.post(server + "user/login", {
			mail: mail.val(),
			password: md5(pw.val())
		}, function(data) {
			if (data.code == 0) {
				mui.toast('登陆失败，请检查邮箱或密码是否填写正确', {
					duration: '2000',
					type: 'div'
				});
				return;
			}
			mui.toast('登陆成功', {
				duration: '2000',
				type: 'div'
			});
			var autoLogin = document.getElementById("autoLogin").classList.contains("mui-active");
			if (autoLogin) {
				localStorage.setItem("mail", data.user.mail);
				localStorage.setItem("pw", data.user.password);
			}
			localStorage.setItem("user", JSON.stringify(data.user));
			window.location.href = "main.html";
		});
	});
});
