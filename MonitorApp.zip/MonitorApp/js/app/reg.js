var server = "http://18r.site:18/";
(function($, doc) {
	$.init({
		statusBarBackground: '#f7f7f7'
	});
	$.plusReady(function() {});
}(mui, document));
$(document).ready(function() {
	var name = $("#name");
	var mail = $("#mail");
	var pw = $("#password");
	var pw2 = $("#password_confirm");
	var reg = $("#reg");
	reg.click(function() {
		if (name.val() == "" || mail.val == "" || pw.val() == "" || pw2.val() == "") {
			mui.toast('请完整的填写注册信息', {
				duration: '2000',
				type: 'div'
			});
			return;
		}
		if (pw.val() != pw2.val()) {
			mui.toast('两次密码填写不一致', {
				duration: '2000',
				type: 'div'
			});
			return;
		}
		$.post(server + "user/reg", {
			name: name.val(),
			mail: mail.val(),
			password: md5(pw.val())
		}, function(data) {
			if (data.code == 0) {
				alert("注册失败，请下辈子再试试吧");
				return;
			}
			mui.toast('注册成功', {
				duration: '2000',
				type: 'div'
			});
			localStorage.setItem("mail", data.user.mail);
			localStorage.setItem("pw", data.user.password);
			localStorage.setItem("user", JSON.stringify(data.user));
			window.location.href = "main.html";

		});

	});
});