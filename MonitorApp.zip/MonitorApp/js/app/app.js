var server = "http://18r.site:18/";
$(document).ready(function() {
	var name = $("#name");
	var mail = $("#mail");
	var pw = $("#password");
	var pw2 = $("#password_confirm");
	var login = $("#login");
	var reg = $("#reg");

	login.click(function() {
		if (mail.val() == "" || pw.val() == "") {
			mui.toast('请填写登陆信息', {
				duration: '2000',
				type: 'div'
			});
			return;
		}
		$.post(server + "user/login", {
			mail: mail.val(),
			password: md5(pw.val())
		}, function(data) {
			if (data.code == 0) {
				mui.toast('登陆失败，请检查邮箱或密码是否填写正确', {
					duration: '2000',
					type: 'div'
				});
				return;
			}
			mui.toast('登陆成功', {
				duration: '2000',
				type: 'div'
			});
			var autoLogin = document.getElementById("autoLogin").classList.contains("mui-active");
			if (autoLogin) {
				localStorage.setItem("mail", data.user.mail);
				localStorage.setItem("pw", data.user.password);
			}
			window.location.href = "main.html";
		});
	});
	reg.click(function() {
		if (name.val() == "" || mail.val == "" || pw.val() == "" || pw2.val() == "") {
			mui.toast('请完整的填写注册信息', {
				duration: '2000',
				type: 'div'
			});
			return;
		}
		if (pw.val() != pw2.val()) {
			mui.toast('两次密码填写不一致', {
				duration: '2000',
				type: 'div'
			});
			return;
		}
		$.post(server + "user/reg", {
			name: name.val(),
			mail: mail.val(),
			password: md5(pw.val())
		}, function(data) {
			if (data.code == 0) {
				alert("注册失败，请下辈子再试试吧");
				return;
			}
			mui.toast('注册成功', {
				duration: '2000',
				type: 'div'
			});
			localStorage.setItem("mail", data.user.mail);
			localStorage.setItem("pw", data.user.password);
			localStorage.setItem("user", JSON.stringify(data.user));
			window.location.href = "main.html";

		});

	});
	exit.click(function() {
		localStorage.setItem("mail", null);
		localStorage.setItem("pw", null);
		localStorage.setItem("user", null);
		window.location.href = "login.html";
	});
});

mui.init();